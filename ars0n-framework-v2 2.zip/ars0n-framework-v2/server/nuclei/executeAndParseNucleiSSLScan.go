package nuclei

var sslTemplates = []string{
	"ssl/deprecated-tls.yaml",
	"ssl/expired-ssl.yaml",
	"ssl/mismatched-ssl-certificate.yaml",
	"ssl/revoked-ssl-certificate.yaml",
	"ssl/self-signed-ssl.yaml",
	"ssl/untrusted-root-certificate.yaml",
}
